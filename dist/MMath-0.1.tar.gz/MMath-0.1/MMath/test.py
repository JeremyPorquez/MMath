import os
# from caverage import caverage
from CMath import caverage

print(caverage([1,2,3]))